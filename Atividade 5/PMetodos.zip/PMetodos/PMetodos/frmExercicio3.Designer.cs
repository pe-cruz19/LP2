﻿namespace PMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_Inverte = new Button();
            btn_remover = new Button();
            lbl_Palavra2 = new Label();
            lbl_Palavra1 = new Label();
            txtPalavra2 = new TextBox();
            txtPalavra1 = new TextBox();
            SuspendLayout();
            // 
            // btn_Inverte
            // 
            btn_Inverte.Font = new Font("Segoe UI", 22F);
            btn_Inverte.Location = new Point(539, 350);
            btn_Inverte.Margin = new Padding(2);
            btn_Inverte.Name = "btn_Inverte";
            btn_Inverte.Size = new Size(282, 114);
            btn_Inverte.TabIndex = 12;
            btn_Inverte.Text = "Inverte o 1º";
            btn_Inverte.UseVisualStyleBackColor = true;
            btn_Inverte.Click += btn_Inverte_Click;
            // 
            // btn_remover
            // 
            btn_remover.Font = new Font("Segoe UI", 22F);
            btn_remover.Location = new Point(165, 350);
            btn_remover.Margin = new Padding(2);
            btn_remover.Name = "btn_remover";
            btn_remover.Size = new Size(282, 114);
            btn_remover.TabIndex = 11;
            btn_remover.Text = "Remova 1º do 2º";
            btn_remover.UseVisualStyleBackColor = true;
            btn_remover.Click += btn_remover_Click;
            // 
            // lbl_Palavra2
            // 
            lbl_Palavra2.AutoSize = true;
            lbl_Palavra2.Font = new Font("Segoe UI", 22F);
            lbl_Palavra2.Location = new Point(165, 214);
            lbl_Palavra2.Margin = new Padding(2, 0, 2, 0);
            lbl_Palavra2.Name = "lbl_Palavra2";
            lbl_Palavra2.Size = new Size(169, 50);
            lbl_Palavra2.TabIndex = 10;
            lbl_Palavra2.Text = "Palavra 2";
            // 
            // lbl_Palavra1
            // 
            lbl_Palavra1.AutoSize = true;
            lbl_Palavra1.Font = new Font("Segoe UI", 22F);
            lbl_Palavra1.Location = new Point(165, 139);
            lbl_Palavra1.Margin = new Padding(2, 0, 2, 0);
            lbl_Palavra1.Name = "lbl_Palavra1";
            lbl_Palavra1.Size = new Size(169, 50);
            lbl_Palavra1.TabIndex = 9;
            lbl_Palavra1.Text = "Palavra 1";
            // 
            // txtPalavra2
            // 
            txtPalavra2.Font = new Font("Segoe UI", 22F);
            txtPalavra2.Location = new Point(352, 212);
            txtPalavra2.Margin = new Padding(2);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(323, 56);
            txtPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Font = new Font("Segoe UI", 22F);
            txtPalavra1.Location = new Point(352, 137);
            txtPalavra1.Margin = new Padding(2);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(323, 56);
            txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1411, 697);
            Controls.Add(btn_Inverte);
            Controls.Add(btn_remover);
            Controls.Add(lbl_Palavra2);
            Controls.Add(lbl_Palavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_Inverte;
        private Button btn_remover;
        private Label lbl_Palavra2;
        private Label lbl_Palavra1;
        private TextBox txtPalavra2;
        private TextBox txtPalavra1;
    }
}