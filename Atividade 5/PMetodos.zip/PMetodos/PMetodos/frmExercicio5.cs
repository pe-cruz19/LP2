﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btn_remover_Click(object sender, EventArgs e)
        {
            Random sorteio = new Random();

            if (num1 < num2)
            {
                int num = sorteio.Next(num1, num2);
                MessageBox.Show("Número sorteado: " + num);
            }
            else
            {
                MessageBox.Show("O primeiro valor não é menor que o segundo");
            }

            }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!(int.TryParse(txtNumero1.Text, out num1)))
            {
                MessageBox.Show("Valor inválido, precisa ser um número inteiro");
                
            }

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!(int.TryParse(txtNumero2.Text, out num2)))
            {
                MessageBox.Show("Valor inválido, precisa ser um número inteiro");
                
            }
        }
    }
}
