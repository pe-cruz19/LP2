﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            lbl_Palavra1 = new Label();
            lbl_Palavra2 = new Label();
            btn_verifica = new Button();
            btn_inserirPrimeiro = new Button();
            btn_inserirAsterisco = new Button();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Font = new Font("Segoe UI", 22F);
            txtPalavra1.Location = new Point(322, 85);
            txtPalavra1.Margin = new Padding(2, 2, 2, 2);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(323, 56);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Font = new Font("Segoe UI", 22F);
            txtPalavra2.Location = new Point(322, 160);
            txtPalavra2.Margin = new Padding(2, 2, 2, 2);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(323, 56);
            txtPalavra2.TabIndex = 1;
            // 
            // lbl_Palavra1
            // 
            lbl_Palavra1.AutoSize = true;
            lbl_Palavra1.Font = new Font("Segoe UI", 22F);
            lbl_Palavra1.Location = new Point(135, 87);
            lbl_Palavra1.Margin = new Padding(2, 0, 2, 0);
            lbl_Palavra1.Name = "lbl_Palavra1";
            lbl_Palavra1.Size = new Size(169, 50);
            lbl_Palavra1.TabIndex = 2;
            lbl_Palavra1.Text = "Palavra 1";
            // 
            // lbl_Palavra2
            // 
            lbl_Palavra2.AutoSize = true;
            lbl_Palavra2.Font = new Font("Segoe UI", 22F);
            lbl_Palavra2.Location = new Point(135, 162);
            lbl_Palavra2.Margin = new Padding(2, 0, 2, 0);
            lbl_Palavra2.Name = "lbl_Palavra2";
            lbl_Palavra2.Size = new Size(169, 50);
            lbl_Palavra2.TabIndex = 3;
            lbl_Palavra2.Text = "Palavra 2";
            // 
            // btn_verifica
            // 
            btn_verifica.Font = new Font("Segoe UI", 22F);
            btn_verifica.Location = new Point(135, 298);
            btn_verifica.Margin = new Padding(2, 2, 2, 2);
            btn_verifica.Name = "btn_verifica";
            btn_verifica.Size = new Size(282, 114);
            btn_verifica.TabIndex = 4;
            btn_verifica.Text = "Verificar Iguais";
            btn_verifica.UseVisualStyleBackColor = true;
            btn_verifica.Click += btn_verifica_Click;
            // 
            // btn_inserirPrimeiro
            // 
            btn_inserirPrimeiro.Font = new Font("Segoe UI", 22F);
            btn_inserirPrimeiro.Location = new Point(509, 298);
            btn_inserirPrimeiro.Margin = new Padding(2, 2, 2, 2);
            btn_inserirPrimeiro.Name = "btn_inserirPrimeiro";
            btn_inserirPrimeiro.Size = new Size(282, 114);
            btn_inserirPrimeiro.TabIndex = 5;
            btn_inserirPrimeiro.Text = "Inserir 1° no meio do 2°";
            btn_inserirPrimeiro.UseVisualStyleBackColor = true;
            btn_inserirPrimeiro.Click += btn_inserirPrimeiro_Click;
            // 
            // btn_inserirAsterisco
            // 
            btn_inserirAsterisco.Font = new Font("Segoe UI", 22F);
            btn_inserirAsterisco.Location = new Point(882, 298);
            btn_inserirAsterisco.Margin = new Padding(2, 2, 2, 2);
            btn_inserirAsterisco.Name = "btn_inserirAsterisco";
            btn_inserirAsterisco.Size = new Size(282, 114);
            btn_inserirAsterisco.TabIndex = 6;
            btn_inserirAsterisco.Text = "Inserir 2 * no meio do 1°";
            btn_inserirAsterisco.UseVisualStyleBackColor = true;
            btn_inserirAsterisco.Click += btn_inserirAsterisco_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1401, 541);
            Controls.Add(btn_inserirAsterisco);
            Controls.Add(btn_inserirPrimeiro);
            Controls.Add(btn_verifica);
            Controls.Add(lbl_Palavra2);
            Controls.Add(lbl_Palavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Margin = new Padding(2, 2, 2, 2);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Label lbl_Palavra1;
        private Label lbl_Palavra2;
        private Button btn_verifica;
        private Button btn_inserirPrimeiro;
        private Button btn_inserirAsterisco;
    }
}