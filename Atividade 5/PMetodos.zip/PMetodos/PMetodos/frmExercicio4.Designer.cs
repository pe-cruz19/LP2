﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btn_PosBranco = new Button();
            btn_ContaNum = new Button();
            btn_ContaLetras = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.BackColor = SystemColors.MenuBar;
            rchtxtFrase.Font = new Font("Microsoft Sans Serif", 8.25F);
            rchtxtFrase.Location = new Point(178, 43);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(424, 236);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            rchtxtFrase.TextChanged += rchtxtFrase_TextChanged;
            // 
            // btn_PosBranco
            // 
            btn_PosBranco.Font = new Font("Segoe UI", 18F);
            btn_PosBranco.Location = new Point(314, 303);
            btn_PosBranco.Margin = new Padding(2);
            btn_PosBranco.Name = "btn_PosBranco";
            btn_PosBranco.Size = new Size(179, 134);
            btn_PosBranco.TabIndex = 14;
            btn_PosBranco.Text = "Posição 1º caracter branco";
            btn_PosBranco.UseVisualStyleBackColor = true;
            btn_PosBranco.Click += btn_PosBranco_Click;
            // 
            // btn_ContaNum
            // 
            btn_ContaNum.Font = new Font("Segoe UI", 18F);
            btn_ContaNum.Location = new Point(62, 301);
            btn_ContaNum.Margin = new Padding(2);
            btn_ContaNum.Name = "btn_ContaNum";
            btn_ContaNum.Size = new Size(179, 134);
            btn_ContaNum.TabIndex = 13;
            btn_ContaNum.Text = "Conta Números";
            btn_ContaNum.UseVisualStyleBackColor = true;
            btn_ContaNum.Click += btn_ContaNum_Click;
            // 
            // btn_ContaLetras
            // 
            btn_ContaLetras.Font = new Font("Segoe UI", 18F);
            btn_ContaLetras.Location = new Point(566, 305);
            btn_ContaLetras.Margin = new Padding(2);
            btn_ContaLetras.Name = "btn_ContaLetras";
            btn_ContaLetras.Size = new Size(179, 134);
            btn_ContaLetras.TabIndex = 15;
            btn_ContaLetras.Text = "Conta Letras";
            btn_ContaLetras.UseVisualStyleBackColor = true;
            btn_ContaLetras.Click += btn_ContaLetras_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_ContaLetras);
            Controls.Add(btn_PosBranco);
            Controls.Add(btn_ContaNum);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            Load += frmExercicio4_Load;
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btn_PosBranco;
        private Button btn_ContaNum;
        private Button btn_ContaLetras;
    }
}