﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"digite o {i + 1}° numero", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {

                    MessageBox.Show("Valor inválido");
                    i--;
                }
                else
                {
                    saida = auxiliar + "\n" + saida;
                }

            }
            MessageBox.Show(saida);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() { "Ana", "Andre", "beatriz", "Camila", "João", "Joana", "Otavio", "Marcelo", "Pedro", "thaina" };

            Lista.Remove("Otavio");
            String auxiliar = "";
            foreach (String nome in Lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];

            string auxiliar = "";
            double media = 0;
            string Saida = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {

                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(double.TryParse(auxiliar, out notas[i, j])) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado inválido");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                Saida += $"\nAluno: {i + 1}: Média: {media / 3}";
                media = 0;
            }
            MessageBox.Show(Saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            Form2 exercicio4 = new Form2();
            exercicio4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Form3 exercicio5 = new Form3();
            exercicio5.Show();
        }
    }
}
