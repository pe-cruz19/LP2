﻿namespace Atividade8
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVeri = new System.Windows.Forms.Button();
            this.LstBoxVerificacao = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVeri
            // 
            this.btnVeri.Location = new System.Drawing.Point(68, 137);
            this.btnVeri.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVeri.Name = "btnVeri";
            this.btnVeri.Size = new System.Drawing.Size(157, 52);
            this.btnVeri.TabIndex = 0;
            this.btnVeri.Text = "verificar";
            this.btnVeri.UseVisualStyleBackColor = true;
            this.btnVeri.Click += new System.EventHandler(this.btnVeri_Click);
            // 
            // LstBoxVerificacao
            // 
            this.LstBoxVerificacao.FormattingEnabled = true;
            this.LstBoxVerificacao.ItemHeight = 16;
            this.LstBoxVerificacao.Location = new System.Drawing.Point(377, 16);
            this.LstBoxVerificacao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LstBoxVerificacao.Name = "LstBoxVerificacao";
            this.LstBoxVerificacao.Size = new System.Drawing.Size(321, 324);
            this.LstBoxVerificacao.TabIndex = 1;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.LstBoxVerificacao);
            this.Controls.Add(this.btnVeri);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVeri;
        private System.Windows.Forms.ListBox LstBoxVerificacao;
    }
}