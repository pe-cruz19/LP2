﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnVeri_Click(object sender, EventArgs e)
        {
            string[,] aluno = new string[25, 10];
            int i = 0;
            char[] gabarito = new char[10] { 'A', 'B', 'C', 'D', 'E', 'A', 'A', 'A', 'A', 'A' };
            char resposta;

            for (i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aluno[i, j] = Interaction.InputBox($"Escolha uma alternativa para a questão {j + 1}: A,B,C,D ou E", "Entrada de nomes");
                    if (Char.TryParse(aluno[i, j], out resposta) && (char.ToUpper(resposta) < 70) && (char.ToUpper(resposta) > 64))
                    {
                        if (resposta == gabarito[j])
                        {
                            LstBoxVerificacao.Items.Add($"O aluno {i + 1} acertou a questão: {j + 1}. Alternativa correta: {gabarito[j]}, escolheu {resposta}");
                          }
                        else
                        {
                            LstBoxVerificacao.Items.Add($"O aluno {i + 1} errou a questão: {j + 1}. Alternativa correta:{gabarito[j]}, escolheu {resposta}");
                            }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;

                    }
                }
            }
        }
    }
}

