﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            int letras = 0;
            string[] nomes = new string[10];
            int i = 0;



            for (i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome:", "Entrada de nomes");

                foreach (char x in nomes[i])
                {


                    if (char.IsLetter(x))
                    {
                        letras++;
                    }
                }
                    if (letras <= 0)
                    {
                        MessageBox.Show("nome inválido");
                        i--;
                    }
                        else
                        {
                            listBox1.Items.Add($"- Nome: {nomes[i]} tem {letras} caracteres");
                         }
                    letras = 0;


                
            }
        
            
        }
    }
}
