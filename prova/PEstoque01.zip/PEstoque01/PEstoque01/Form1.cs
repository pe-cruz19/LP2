﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] produtos = new string[4, 2];
            int i = 0;
            int j = 0;
            double total = 0;
            double mes = 0;
            double quant = 0;

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    produtos[j, i] = Interaction.InputBox($"Insira a quantidade do produto {j + 1} na semana {i + 1}", "entrada de mercadoria");
                    if (Double.TryParse(produtos[j, i], out quant) && quant >= 0)
                    {
                        mes = quant + mes;
                        listaProdutos.Items.Add($"Total de entradas do produto {j + 1} na semana {i + 1}: {quant}");

                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida");
                        i--;

                    }

                }
                total = total + mes;
                listaProdutos.Items.Add($"Total de entradas do produto {j + 1} no mês é de: {mes}");
                listaProdutos.Items.Add("-------------------------------------------------------------------");
                mes = 0;
            }
            listaProdutos.Items.Add($"Total de produtos no mês: {total}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listaProdutos.Items.Clear();
        }
    }
}
