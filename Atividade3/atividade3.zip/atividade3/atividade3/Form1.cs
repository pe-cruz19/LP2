﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade3
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            peso = Double.Parse(mskTxtPeso.Text);
            altura = Double.Parse(mskTxtAltura.Text);
            if (peso == 0)
            {
                errorProvider1.SetError(mskTxtPeso, "Peso inválido");
                mskTxtPeso = null;
                mskTxtPeso.Focus();
            }
            if (altura == 0)
            {
                errorProvider2.SetError(mskTxtAltura, "Altura inválida");
                mskTxtAltura = null;
                mskTxtAltura.Focus();
            }

            IMC = peso / (altura * altura);
            IMC=Math.Round(IMC,1);

            if (IMC < 18.5)
            {
                MessageBox.Show("Classificado como magro");
            }
            else if(IMC < 24.9)
            {
                MessageBox.Show("Classificado como normal");
            }
            else if(IMC < 29.9){
                MessageBox.Show("Classificado como sobrepeso");
            }
            else if(IMC < 39.9){
                MessageBox.Show("Classificado como obeso");
            }
            else { MessageBox.Show("Obesidade grave, procure um médico"); }

                txtBoxIMC.Text = IMC.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskTxtAltura.Clear();
            mskTxtPeso.Clear();
            txtBoxIMC.Clear();
        }

        private void mskTxtAltura_Validated(object sender, EventArgs e)
        {
            altura = Double.Parse(mskTxtAltura.Text);
            if (altura == 0)
            {
                errorProvider2.SetError(mskTxtAltura, "Altura inválida");
                mskTxtAltura = null;
               
            }
        }

        private void mskTxtPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskTxtPeso_Validated(object sender, EventArgs e)
        {
            peso = Double.Parse(mskTxtPeso.Text);
            if (peso == 0)
            {
                errorProvider1.SetError(mskTxtPeso, "Peso inválido");
                mskTxtPeso = null;
                
            }
        }
    }
}
